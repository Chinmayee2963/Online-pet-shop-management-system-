<?php
 
   @include 'config.php';
   if(isset($_POST['submit'])){
       $name=mysqli_real_escape_string($conn, $_POST['name']);
       $email=mysqli_real_escape_string($conn, $_POST['email']);
       $password=md5($_POST['password']);
       $cpassword=md5($_POST['cpassword']);
       $user_type=$_POST['user_type'];

       $select="select * from user_form where email='$email' && password='$password' ";

       $result=mysqli_query($conn, $select);

       if(mysqli_num_rows($result) > 0){
             $error[]='user alredy exist!';

             
       }else{

           if($password!=$cpassword){
              $error[]='password not matched!';
           }else{
            $insert="insert into user_form (name, email, password,user_type) values('$name','$email','$password','$user_type')";
            mysqli_query($conn, $insert);
            header('location:login_form.php');
           }
       }
       

   };
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form_container">
    <form action="" method="post">
        <h3>Register now</h3>
        
        <?php
            if(isset($error)){
                foreach($error as $error){
                    echo '<span class="error-msg">'.$error.'</span>';
                };
            }; 
        ?>
        <label for="name"><b>Name:</b></label>
        <input  class="form control" id="name" type="name" name="name" required><br>

                  <label for="email"><b>Email:</b></label>
                  <input  class="form control" id="email" type="email" name="email" required><br>

                  <label for="password"><b>Password:</b></label>
                  <input  class="form control" id="password" type="password" name="password" required placeholdaer="enter the password"><br>

                  <label for="cpassword"><b>confirm password:</b></label>
                  <input  class="form control" id="cpassword" type="cpassword" name="cpassword" required><br>
        <!--<input type="text" name="name" required placeholdaer="enter your name">
        <input type="email" name="email" required >
        <input type="password" name="password" required >
        <input type="password" name="password" required >-->

        <select name="user_type"><br>
            <option value="user">user</option>
            <option value="admin">admin</option>
        </select><nr><br>

        <button type="submit" name="submit" value="register now" class="form-btn">register now</button><br><br>
        <p>already have an account?<a href="login_form.php">login now</a></p>
    </form>

</div>
    
</body>
</html>