<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Information System</title>
    <link rel="stylesheet" href="homepage.css">
    <id>
    
    <style>
    
        /* Resetting default browser styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: url('pet.jpg');
            background-size:cover;
            display:flex;
            height:100vh;
            background-position: center;
           
        }

        .container {
            max-width: 600px;
            margin: 200px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        /* Navigation Bar styles */
        nav {
            width: 100%;
            height:100px;
            position: fixed;
            top:0;
            justify-content: space-around;
            display: flex;
            align-items: center;
            background-image: linear-gradient(#033747,#012733);
        }
    
        
         p{
           font-size: 30px;
           font-weight: bold;
           color:white;
           text-transform: uppercase;
           letter-spacing: 1.5px;

        }
        nav a{
        font-size: 18px;
        display: flex;
        text-transform: uppercase;
        padding: 0px 20px;
        color:white;
        text-decoration: none;
       }
      nav a:hover{
      color: #ff8c69;
      transition: all 0.4s ease 0s ;
      }
      
    </style>
</head>


<body>
    
    <nav>
        <p>PETSHOP</p>
        <a class="active" href="#">Home</a>
       
                <a class="nav-link" href="login_form.php">LOGIN</a>
                <a href="register_from.php">REGISTRATION</a>
                <a href="#">ABOUT</a>
    </nav>
    <div id="div">
    <h2> PAWsitive Vibe Only</h2>
    </div>
    
    
</body>
</html>
