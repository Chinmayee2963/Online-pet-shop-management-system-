<?php
@include 'config1.php';

$message = []; // Define an empty array to store messages

if(isset($_POST['update_product'])) {
    // Retrieving form data
    $id = $_POST['product_id']; // Assuming you have a hidden input field for product_id
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_FILES['product_image']['name'];
    $product_image_tmp_name = $_FILES['product_image']['tmp_name'];
    $product_image_folder = 'uploaded_img/' . $product_image;

    // Check if any field is empty
    if(empty($product_name) || empty($product_price) || empty($product_image)) {
        $message[] = 'Please fill all fields';
    } else {
        // Update data in the database
        $update_query = "UPDATE products SET name='$product_name', price='$product_price', image='$product_image' WHERE id='$id'";
        $update_result = mysqli_query($conn, $update_query);
        if($update_result) {
            // Move uploaded image to destination folder
            move_uploaded_file($product_image_tmp_name, $product_image_folder);
            $message[] = 'Product updated successfully';
        } else {
            $message[] = 'Could not update the product';
        }
    }
}

// Fetch product details if edit parameter is set
if(isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $select_query = mysqli_query($conn, "SELECT * FROM products WHERE id='$id'");
    $product_data = mysqli_fetch_assoc($select_query);
} else {
    // Redirect if edit parameter is not set
    header('location:admin_panal.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Product</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>

<div class="container">
    <div class="admin-product-form-container centered">
        <?php
        // Display messages if any
        foreach($message as $msg) {
            echo '<span class="message">' . $msg . '</span>';
        }
        ?>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
            <h3>Update Product</h3>
            <input type="hidden" name="product_id" value="<?php echo $product_data['id']; ?>">
            <input type="text" placeholder="Enter product name" name="product_name" value="<?php echo $product_data['name']; ?>" class="box">
            <input type="number" placeholder="Enter product price" name="product_price" value="<?php echo $product_data['price']; ?>" class="box">
            <input type="file" accept="image/png, image/jpeg, image/jpg" name="product_image" class="box">
            <input type="submit" class="btn" name="update_product" value="Update Product">
        </form>
    </div>
</div>

</body>
</html>
